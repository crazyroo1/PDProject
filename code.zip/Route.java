public class Route {
    public String ip;
    public RouteType type;
}

enum RouteType {
	CLIENT,
	ROUTER
}